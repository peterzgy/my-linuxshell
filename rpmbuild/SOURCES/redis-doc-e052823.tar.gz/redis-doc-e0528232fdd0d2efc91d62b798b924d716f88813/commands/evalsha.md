Evaluates a script cached on the server side by its SHA1 digest.
Scripts are cached on the server side using the `SCRIPT LOAD` command.
The command is otherwise identical to `EVAL`.
