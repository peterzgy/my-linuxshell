Marks the given keys to be watched for conditional execution of a
[transaction][tt].

[tt]: /topics/transactions

@return

@simple-string-reply: always `OK`.
