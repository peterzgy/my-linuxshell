Return a random key from the currently selected database.

@return

@bulk-string-reply: the random key, or `nil` when the database is empty.
