The `LATENCY HELP` command returns a helpful text describing the different
subcommands.

For more information refer to the [Latency Monitoring Framework page][lm].

[lm]: /topics/latency-monitor

@return

@array-reply: a list of subcommands and their descriptions
