`DEBUG OBJECT` is a debugging command that should not be used by clients.
Check the `OBJECT` command instead.

@return

@simple-string-reply
