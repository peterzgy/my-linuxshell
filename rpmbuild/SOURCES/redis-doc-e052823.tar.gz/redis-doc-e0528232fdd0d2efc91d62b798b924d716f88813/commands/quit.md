Ask the server to close the connection.
The connection is closed as soon as all pending replies have been written to the
client.

@return

@simple-string-reply: always OK.
